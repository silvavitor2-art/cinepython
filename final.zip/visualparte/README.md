Nome Do Projeto:Cinepython
Tema:Catálogo de Filme
Instruções de execução:Criamos esse projeto com o objetivo de escolher filmes,o horario, o assento a forma de pagamento etc
Bibliotecas utilizadas:Tkinter,Pillow e Messagebox
Descrição das funcionalidades:A primeira janela aparece para escolher qual filme a pessoa quer assistir depois aparece outra pra mostra os horarios disponiveis para determinado filme em seguida aparece outra pra escolher o seu assento e por ultimo a forma de pagamento
Componentes:Victor Gabriel Linhares Araujo,Andre Rian Dutra de Medeiros, Apolo Gabriel Araujo Costa, Joao Vitor da Silva Santos